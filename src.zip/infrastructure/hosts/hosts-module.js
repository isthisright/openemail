angular.module('apf.infrastructure.hostsModule', []);
