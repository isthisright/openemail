angular.module('apf.infrastructure.providersModule', ['pascalprecht.translate', 'ui.bootstrap']);
