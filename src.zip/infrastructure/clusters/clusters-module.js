angular.module('apf.infrastructure.clustersModule', []);
