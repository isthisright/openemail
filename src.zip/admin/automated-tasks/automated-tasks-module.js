
angular.module('apf.admin.automatedTasksModule', []);
