
angular.module( 'apf.clouds.volumesModule',  []);
