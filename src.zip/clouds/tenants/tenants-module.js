
angular.module( 'apf.clouds.tenantsModule',  []);
