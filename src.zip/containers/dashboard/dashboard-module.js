
angular.module('apf.containers.dashboardModule', ['pascalprecht.translate', 'ui.bootstrap']);
