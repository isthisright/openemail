
angular.module('apf.containers.imagesModule', []);
