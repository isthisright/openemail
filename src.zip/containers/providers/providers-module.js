angular.module('apf.containers.providersModule', ['pascalprecht.translate', 'ui.bootstrap']);
