
angular.module('apf.containers.routesModule', []);
