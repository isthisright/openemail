
angular.module('apf.containers.nodesModule', []);
