
angular.module('apf.containers.servicesModule', []);
