
angular.module('apf.containers.projectsModule', ['pascalprecht.translate', 'ui.bootstrap']);
